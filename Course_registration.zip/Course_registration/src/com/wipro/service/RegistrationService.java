package com.wipro.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.wipro.userbean.RegisterBean;
import com.wipro.util.DBUtil;
import com.wipro.util.InvalidCourseException;
import com.wipro.util.InvalidRegistrationException;
import com.wipro.util.InvalidUserIDException;

public class RegistrationService {
	Connection con;
	Statement stmt;
	ResultSet rs;
	public String validateRequest(RegisterBean regBean) {
		
		if(regBean==null)
		{
			try {
				throw new InvalidRegistrationException();
			}
			catch (InvalidRegistrationException e)
			{
				return e.toString();
			}
		}
		else if(regBean.getUserID().length()!=8 || (!regBean.getUserID().startsWith("ST")) || regBean.getUserID()==null )
		{
			try {
				throw new InvalidUserIDException();
			}
			catch (InvalidUserIDException e)
			{
				return e.toString();
			}
		}
		else if(regBean.getCourseIDToRegister().length()!=6 || (!regBean.getCourseIDToRegister().startsWith("CS")) || regBean.getCourseIDToRegister()==null)
		{
			try {
				throw new InvalidCourseException();
			}
			catch (InvalidCourseException e)
			{
				return e.toString();
			}
		}
		//System.out.println("SUCCESS");
		return "SUCCESS";
	}
	
	public String checkCourseAvailability(RegisterBean regBean) {
		
		if(validateRequest(regBean).equals("SUCCESS")) {
			//System.out.println("TTTT");
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="select * from CourseTable where CourseID='"+regBean.getCourseIDToRegister()+"'";
				rs = stmt.executeQuery(query);
				if(rs.next()) 
					return "AVAILABLE";
				else
					return"Course Not Available";
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return validateRequest(regBean);
		return null;
		
	}
	
	public String registerCourse(RegisterBean regBean) {
		//System.out.println(checkCourseAvailability(regBean));
		if(checkCourseAvailability(regBean).equals("AVAILABLE"))
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("22Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("22Creating statement...");
				PreparedStatement ps=con.prepareStatement("insert into RegistrationTable values (?,?,?)");
				ps.setString(1,regBean.getUserID());
				ps.setString(2,regBean.getStudentName());
				ps.setString(3,regBean.getCourseIDToRegister());
				int rs=ps.executeUpdate();  
				System.out.println(rs+" records affected");
				if(rs>0)
				return "Registration Successful";
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return checkCourseAvailability(regBean);
		return null;
		
	}
	
	public boolean isRegistered(String userID, String courseID) {
		DBUtil db = new DBUtil();
		try {
			 con = db.getDBConnection();
			 //System.out.println("Connected database successfully...");
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from RegistrationTable where CourseRegistered='"+courseID+"' AND UserID='"+userID+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return true;
			else
				return false;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
		
	}
	
	public String cancelRegistration(String userID, String courseID) {
		if(isRegistered(userID,courseID)==true)
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="delete from RegistrationTable where CourseRegistered='"+courseID+"' AND UserID='"+userID+"'";
				rs = stmt.executeQuery(query);
				if(rs.next())
					return courseID+" registration canceled for the user "+userID;
				
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return "Your cancellation request failed, you are not the registered user for the course "+courseID;
		return null;
		
	}
	
	public String updateCourseID(String userID, String courseID) {
		if(isRegistered(userID,courseID)==true)
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				//String query="select CourseRegistered from RegistrationTable where UserID='"+userID+"'";
				//rs=stmt.executeQuery(query);
				//rs.next();
				//String oldCourse=rs.getString(1);
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter new course id to update");
				String newcourse=sc.next();
				String query="update RegistrationTable set courseregistered='"+newcourse+"' where UserID='"+userID+"' and courseregistered='"+courseID+"'";
				int r=stmt.executeUpdate(query);
				if(r>0)
					return "Course Updated Successfully,old course: "+courseID+", new course: "+newcourse;
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return "Your update request failed, You are not the registered user for the course "+courseID;
		return null;
		
		
	}
}
