package com.wipro.service;

import java.util.ArrayList;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import javax.swing.text.html.HTMLDocument.Iterator;

import com.wipro.userbean.CourseBean;
import com.wipro.userbean.RegisterBean;
import com.wipro.util.DBUtil;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char ch;
		do {
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		RegisterBean r=new RegisterBean();
		CourseBean c=new CourseBean();
		RegistrationService reg=new RegistrationService();
		AdminService adm=new AdminService();
		
		int n;
		String userid,courseid,name;
		System.out.println("---------------------------------------------------------------------------------------------------------------------------");
		System.out.println("\t\t\t\t\t\tONLINE COURSE REGISTRATION");
		System.out.println("---------------------------------------------------------------------------------------------------------------------------");
		System.out.println("\n1.Course Register\n2.Cancel course register\n3.Update course register\n4.Create Course\n5.Delete Course\n6.Update course\n7.Count for Course\n8.Count for user\n9.Available Course detail\n10.Available course ID\n11.Available Course Name\n12.Available course with maximum duration\n13.Available course with minimum duration\n");
		n=sc.nextInt();
		switch(n){
			case 1:
				System.out.println("COURSE REGISTRATION");
				System.out.println("Enter user ID");
				r.setUserID(sc.next());
				System.out.println("Enter student name");
				r.setStudentName(sc.next());
				System.out.println("Enter course ID to reg");
				r.setCourseIDToRegister(sc.next());
				System.out.println(reg.registerCourse(r));
				break;
			case 2:
				System.out.println("COURSE CANCELLATION");
				System.out.println("Enter user ID");
				userid=sc.next();
				System.out.println("Enter course ID to cancel");
				courseid=sc.next();
				System.out.println(reg.cancelRegistration(userid,courseid));
				break;
			case 3:
				System.out.println("COURSE UPDATION");
				System.out.println("Enter user ID");
				userid=sc.next();
				System.out.println("Enter course ID to update");
				courseid=sc.next();
				System.out.println(reg.updateCourseID(userid,courseid));
				break;
			case 4:
				System.out.println("NEW COURSE ENTRY");
				System.out.println("Enter the course name to create");
				c.setCourseName(sc1.nextLine());
				System.out.println("Enter the number of days");
				c.setDays(sc.nextInt());
				Connection con;
				Statement stmt;
				ResultSet rs;
				DBUtil db = new DBUtil();
				try {
					 con = db.getDBConnection();
					 //System.out.println("Connected database successfully...");
					stmt = con.createStatement();
					 //System.out.println("Creating statement...");
					String query="select COURSE_SEQUENCE.NEXTVAL from DUAL";
					rs=stmt.executeQuery(query);
					rs.next();
					c.setCourseID("CS"+rs.getInt(1));}
				catch(SQLException e) {
					e.printStackTrace();
					}
				System.out.println(adm.createCourse(c));
				break;
			case 5:
				System.out.println("COURSE DELETION");
				System.out.println("Enter the course ID to delete");
				courseid=sc.next();
				System.out.println(adm.deleteCourse(courseid));
				break;
			case 6:
				System.out.println("COURSE DETAIL UPDATION");
				System.out.println("Enter the course ID to update");
				courseid=sc.next();
				System.out.println("Enter the course name to update");
				name=sc1.nextLine();
				System.out.println(adm.updateCourseName(courseid, name));
				break;
			case 7:
				System.out.println("ENTRY COUNT FOR COURSE");
				System.out.println("Enter the course ID to count");
				courseid=sc.next();
				System.out.println(adm.countEntries(courseid));
				break;
			case 8:
				System.out.println("ENTRY COUNT FOR USER");
				System.out.println("Enter the userid");
				userid=sc.next();
				System.out.println(adm.countEntries(userid,0));
				break;
			case 9:
				System.out.println("AVAILABLE COURSE DETAILS");
				ArrayList <CourseBean> array=adm.getAllCourses();
				java.util.Iterator<CourseBean> i=array.iterator();
				while (i.hasNext()) {
					CourseBean t = (CourseBean) i.next();
					System.out.println(" Course ID : "+t.getCourseID()+" Course Name : "+t.getCourseName()+" Days : "+t.getDays());
				}
				break;
			case 10:
				System.out.println("AVAILABLE COURSE ID");
				adm.printCourseID();
				break;
			case 11:
				System.out.println("AVAILABLE COURSE NAME");
				adm.printCourseName();
				break;
			case 12:
				System.out.println("COURSE WITH MAXIMUM DURATION");
				adm.maxDayCourse();
				break;
			case 13:
				System.out.println("COURSE WITH MINIMUM DURATION");
				adm.minDayCourse();
				break;
			default: 
				System.out.println("Enter the correct choice");
		}
		System.out.println("Want to continue(y/n)");
		ch=sc.next().charAt(0);
		}while(ch=='y'||ch=='Y');
	}

}
