package com.wipro.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wipro.userbean.CourseBean;
import com.wipro.util.DBUtil;
import com.wipro.util.InvalidCourseDayException;
import com.wipro.util.InvalidCourseException;
import com.wipro.util.InvalidCourseNameException;

public class AdminService {
	Connection con;
	Statement stmt;
	ResultSet rs;
	public String validateRequest(CourseBean courseBean) {
		if(courseBean.getCourseID().length()!=6 || (!courseBean.getCourseID().startsWith("CS")) || courseBean.getCourseID()==null)
		{
			try {
				throw new InvalidCourseException();
			}
			catch (InvalidCourseException e)
			{
				return e.toString();
			}
		}
		else if(courseBean.getCourseName()==null || courseBean.getCourseName().equals("") ||courseBean.getCourseName().length()<2)
		{
			try {
				throw new InvalidCourseNameException();
			}
			catch (InvalidCourseNameException e)
			{
				return e.toString();
			}
		}
		else if(courseBean.getDays()<0)
		{
			try {
				throw new InvalidCourseDayException();
			}
			catch (InvalidCourseDayException e)
			{
				return e.toString();
			}
		}
		return "SUCCESS";
		
	}
	
	public String createCourse(CourseBean cbean) {
		if(validateRequest(cbean).equals("SUCCESS"))
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				/*String query="select COURSE_SEQUENCE.NEXTVAL from DUAL";
				rs=stmt.executeQuery(query);
				rs.next();
				cbean.setCourseID("CS"+rs.getInt(1));*/
				PreparedStatement ps=con.prepareStatement("insert into CourseTable values (?,?,?)");
				ps.setString(1,cbean.getCourseID());
				ps.setString(2,cbean.getCourseName());
				ps.setInt(3,cbean.getDays());
				int rs=ps.executeUpdate();  
				System.out.println(rs+" records affected");
				if(rs>0)
				return "New Course Added: "+cbean.getCourseName();
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return validateRequest(cbean);
		return null;
		
	}
	public boolean isCourseAvailable(String courseID) {
		DBUtil db = new DBUtil();
		try {
			 con = db.getDBConnection();
			 //System.out.println("Connected database successfully...");
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from CourseTable where CourseID='"+courseID+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return true;
			else
				return false;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	public String updateCourseName(String courseID, String name) {
		if(isCourseAvailable(courseID)==true)
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="select CourseName from CourseTable where courseID='"+courseID+"'";
				rs=stmt.executeQuery(query);
				rs.next();
				String oldCourse=rs.getString(1);
				query="update CourseTable set CourseName ='"+name+"' where courseID='"+courseID+"'";
				int r=stmt.executeUpdate(query);
				if(r>0)
					return "Course Name Updated as "+name+" for the course "+oldCourse;
				
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return "Course Not Available, update failed";
		return name;
		
	}
	
	public String deleteCourse(String courseID) {
		if(isCourseAvailable(courseID)==true)
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="delete from CourseTable where CourseID='"+courseID+"'";
				rs = stmt.executeQuery(query);
				if(rs.next())
					return "Course Deleted: "+courseID;
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return "Course Deletion Failed ";
		return null;
		
	}
	public String countEntries(String courseID) {
		if(isCourseAvailable(courseID)==true)
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="select * from RegistrationTable where CourseRegistered='"+courseID+"'";
				rs = stmt.executeQuery(query);
				int count=0;
				while(rs.next())
					count++;
					return courseID+":"+count+" registrants";
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return "Course Not Found";
		return null;
		
	}
	
	public String isRegisteredUser(String userID) {
		DBUtil db = new DBUtil();
		try {
			 con = db.getDBConnection();
			 //System.out.println("Connected database successfully...");
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from RegistrationTable where UserID='"+userID+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return "true";
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
	return "false";
	}
	
	public String countEntries(String userID, int value) {
		if(isRegisteredUser(userID)=="true")
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="select * from RegistrationTable where userID='"+userID+"'";
				rs = stmt.executeQuery(query);
				rs.next();
				String name=rs.getString(2);
				value++;
				while(rs.next())
					value++;
					return name+":"+value+" courses";
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
		}
		else
			return "User Not Found";
		return null;
		
		
	}
	
	public ArrayList<CourseBean> getAllCourses(){
		ArrayList<CourseBean> array=null;
		DBUtil db = new DBUtil();
		try {
			 con = db.getDBConnection();
			 //System.out.println("Connected database successfully...");
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from CourseTable";
			rs = stmt.executeQuery(query);
			array=new ArrayList<CourseBean>();
			while(rs.next()) {
				CourseBean c=new CourseBean();
				c.setCourseID(rs.getString(1));
				c.setCourseName(rs.getString(2));
				c.setDays(rs.getInt(3));
				array.add(c);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return array;
		
	}
	
	public void printCourseName() {
		if(getAllCourses()==null)
			System.out.println("No Records Found");
		else {ArrayList <CourseBean> array=getAllCourses();
		java.util.Iterator<CourseBean> i=array.iterator();
		while (i.hasNext()) {
			CourseBean t = (CourseBean) i.next();
		System.out.println(t.getCourseName());}
		}
	}
	
	public void printCourseID() {
		if(getAllCourses()==null)
			System.out.println("No Records Found");
		else {
			ArrayList <CourseBean> array=getAllCourses();
			java.util.Iterator<CourseBean> i=array.iterator();
			while (i.hasNext()) {
				CourseBean t = (CourseBean) i.next();
			System.out.println(t.getCourseID());}
		}
	}
	public void maxDayCourse()
	{
			DBUtil db = new DBUtil();
			try {
				 con = db.getDBConnection();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="select * from CourseTable order by days desc";
				rs = stmt.executeQuery(query);
				rs.next();
				System.out.println("Course with maximum day is "+rs.getString(2));
			}
			catch(SQLException e) {
				e.printStackTrace();
				}
	}
	public void minDayCourse() {
		DBUtil db = new DBUtil();
		try {
			 con = db.getDBConnection();
			 //System.out.println("Connected database successfully...");
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from CourseTable order by days";
			rs = stmt.executeQuery(query);
			rs.next();
			System.out.println("Course with minimum day is "+rs.getString(2));
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
	}
}
