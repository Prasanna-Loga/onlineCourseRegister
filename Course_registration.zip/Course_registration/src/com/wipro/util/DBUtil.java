package com.wipro.util;

//import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtil {
	public static Connection getDBConnection() {
		Connection con = null;
		try {
			//System.out.println("!!!");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "prasanna");
			return con;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		} 
		catch (ClassNotFoundException e) {
			//System.out.println("YYY");
			e.printStackTrace();
		}
		System.out.println(con);
		return con;
	}
}
