package com.wipro.util;

public class InvalidCourseNameException  extends Exception{
	public String toString() {
		return "��Invalid Course Name";
	}

}

