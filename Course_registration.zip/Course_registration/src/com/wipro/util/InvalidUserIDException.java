package com.wipro.util;

public class InvalidUserIDException  extends Exception{
	public String toString() {
		return "Invalid UserID";
	}

}

