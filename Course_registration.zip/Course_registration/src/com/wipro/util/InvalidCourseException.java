package com.wipro.util;

public class InvalidCourseException  extends Exception{
	public String toString() {
		return "Invalid Course ID";
	}

}

