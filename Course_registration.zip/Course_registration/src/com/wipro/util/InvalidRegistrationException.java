package com.wipro.util;

public class InvalidRegistrationException extends Exception{
	public String toString() {
		return "�Invalid Registration Request";
	}

}
