package com.wipro.util;

public class InvalidCourseDayException  extends Exception{
	public String toString() {
		return "�Invalid Course";
	}

}

