package com.wipro.userbean;

public class RegisterBean {
	private String userID;
	private String studentName;
	private String courseIDToRegister;
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getCourseIDToRegister() {
		return courseIDToRegister;
	}
	public void setCourseIDToRegister(String courseIDToRegister) {
		this.courseIDToRegister = courseIDToRegister;
	}
}
